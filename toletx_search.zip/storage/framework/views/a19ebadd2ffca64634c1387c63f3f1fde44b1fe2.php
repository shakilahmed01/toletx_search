
<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('post_product')); ?>">
<?php echo csrf_field(); ?>

<input class="form-control" name="name">
<input class="form-control" name="category_id">
<button class="btn btn-primary"  type="submit" >Submit</button>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_project\toletx_search\resources\views/product.blade.php ENDPATH**/ ?>