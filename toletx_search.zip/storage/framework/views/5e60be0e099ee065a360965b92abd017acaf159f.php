<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ToletX</title>
</head>
<body>
   
</body>
</html>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href='https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css' rel='stylesheet'> 

    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->

    <!-- Font Awesome CSS -->
    <!-- <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css' rel='stylesheet'> -->
 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
 
    <!--Custom CSS for header  -->
    
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/lite.css')); ?>">
    
    <!-- <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/top-searchbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/body.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/footer.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/advertise.css')); ?>"> -->

    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script type='text/javascript'
        src='https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js'></script> 
  </head>
    <style>
        /* .mt-ad {
            margin-top: 9.3rem!important;
        } */
      </style>
  <body>    
    <!-- Advertise Section Start -->
    <section class="  mt-ad ad-card-body "> 
        <div class="container">
            <div class="row"> 
                <div class="col-md-12">  
                  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                  <div class="carousel-inner advertise">
                    <div class="carousel-item active">
                      <img src="https://media-eng.dhakatribune.com/uploads/2021/01/screenshot-20210122-143010-1611304259766.jpg" class="d-block w-100 advertise-img" style="width: 18rem;" alt="...">
                        <h5 class="card-title text-center">Ad title</h5>
                        <p class="card-text text-center pb-2 pl-2 pr-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis natus dolorem voluptates porro dolores quibusdam maxime consequuntur fugiat numquam corporis.</p>
                    </div>
                    <div class="carousel-item">
                      <img src="https://is1-2.housingcdn.com/4f2250e8/d989169406d3d2b03125b6a6aabd597b/v5/fs/residential_plot-for-sale-kuldiha_1-Durgapur.jpg" class="d-block w-100 advertise-img" style="width: 18rem;" alt="...">
                        <h5 class="card-title text-center">Ad title</h5>
                        <p class="card-text text-center pb-2 pl-2 pr-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis natus dolorem voluptates porro dolores quibusdam maxime consequuntur fugiat numquam corporis.</p>
                    </div>
                    <div class="carousel-item">
                      <img src="https://propertyadviser.in/property-images/s1/shreeda-homes-1298-s1.jpg" class="d-block w-100 advertise-img" style="width: 18rem;" alt="...">
                        <h5 class="card-title text-center">Ad title</h5>
                        <p class="card-text text-center pb-2 pl-2 pr-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis natus dolorem voluptates porro dolores quibusdam maxime consequuntur fugiat numquam corporis.</p>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
                </div>
           </div>
        </div>
    </section>
    <!-- Advertise Section End -->    
  </body>
</html><?php /**PATH D:\new_project\toletx_search\resources\views/frontend/advertise.blade.php ENDPATH**/ ?>