 
     
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/icon.css')); ?>">      
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/assets/css/service_item.css')); ?>">      
  <div class="row mt-2  service-group-row service-group-row">
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 pb-3 main-service text-center" onclick="location.href='<?php echo e(route('room')); ?>'"> 
                                <span class="icon-room service_item"></span>
                                    <br>
                                <span class="service_item_name"> Room</span> 
                        </div> 
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('flat')); ?>'"> 
                                <span class="icon-flat service_item"></span>
                                    <br>
                                <span class="service_item_name"> Flat</span> 
                        </div>  
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('building')); ?>'"> 
                                <span class="icon-building service_item"></span>
                                    <br>
                                <span class="service_item_name"> Building</span> 
                        </div>  
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('parking')); ?>'"> 
                                <span class="icon-parking service_item"></span>
                                    <br>
                                <span class="service_item_name"> Parking Spot</span> 
                        </div>  
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('hotel')); ?>'"> 
                                <span class="icon-hotel service_item"></span>
                                    <br>
                                <span class="service_item_name"> Hotel</span> 
                        </div>     
                    </div>
                    <div class="row mt-2 service-group-row">
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('hostel')); ?>'"> 
                                <span class="icon-hostel service_item"></span>
                                    <br>
                                <span class="service_item_name"> Hostel</span> 
                        </div> 
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('resort')); ?>'"> 
                                <span class="icon-resort service_item"></span>
                                    <br>
                                <span class="service_item_name"> Resort</span> 
                        </div>  
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('office')); ?>'"> 
                                <span class="icon-office service_item"></span>
                                    <br>
                                <span class="service_item_name"> Office</span> 
                        </div>   
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('shop')); ?>'"> 
                                <span class="icon-shop service_item"></span>
                                    <br>
                                <span class="service_item_name"> Shop</span> 
                        </div>    
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('community_hall')); ?>'"> 
                                <span class="icon-community_hall service_item"></span>
                                    <br>
                                <span class="service_item_name">  Community  Hall</span> 
                        </div>     
                    </div>
                    <div class="row mt-2 service-group-row">
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('factory')); ?>'"> 
                                <span class="icon-factory service_item"></span>
                                    <br>
                                <span class="service_item_name">  Factory</span> 
                        </div>  
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('warehouse')); ?>'"> 
                                <span class="icon-warehouse service_item"></span>
                                    <br>
                                <span class="service_item_name">  Warehouse</span> 
                        </div>   
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('land')); ?>'"> 
                                <span class="icon-land service_item"></span>
                                    <br>
                                <span class="service_item_name">  Land</span> 
                        </div>    
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('pond')); ?>'"> 
                                <span class="icon-pond service_item"></span>
                                    <br>
                                <span class="service_item_name">  Pond</span> 
                        </div>     
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('swimming_pool')); ?>'"> 
                                <span class="icon-swimming_pool service_item"></span>
                                    <br>
                                <span class="service_item_name">   Swimming Pool</span> 
                        </div>  
                    </div>
                    
                    <div class="row mt-2 service-group-row">
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('playground')); ?>'"> 
                                <span class="icon-playground service_item" ></span>
                                    <br>
                                <span class="service_item_name"> Play Ground</span> 
                        </div>  
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center"  onclick="location.href='<?php echo e(route('shooting_spot')); ?>'"> 
                                <span class="icon-shooting_spot service_item" ></span>
                                    <br>
                                <span class="service_item_name"> Shooting Spot</span> 
                        </div>  
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center"  onclick="location.href='<?php echo e(route('exhibition_center')); ?>'"> 
                                <span class="icon-exhibition_center service_item"></span>
                                     <br>
                                <span class="service_item_name">  Exhibition Center</span> 
                        </div> 
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('rooftop')); ?>'"> 
                                <span class="icon-rooftop service_item"></span>
                                    <br>
                                <span class="service_item_name">  Rooftop</span> 
                        </div>    
                        <div class="col-md-2 col-small mx-2 pb-3 pt-3 main-service text-center" onclick="location.href='<?php echo e(route('bilboard')); ?>'"> 
                                <span class="icon-bilboard service_item"></span>
                                    <br>
                                <span class="service_item_name"> Bilboard</span> 
                        </div>    
                          
                    </div>
   <?php /**PATH D:\new_project\toletx_search\resources\views/frontend/service_item.blade.php ENDPATH**/ ?>