<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\new_project\toletx_search\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>