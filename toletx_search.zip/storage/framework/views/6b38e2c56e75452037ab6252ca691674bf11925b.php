<div class="pre-loader">
  <div class="pre-loader-box">
    <div class="loader-logo"><img src="vendors/images/deskapp-logo.svg')}}" alt=""></div>
    <div class='loader-progress' id="progress_div">
      <div class='bar' id='bar1'></div>
    </div>
    <div class='percent' id='percent1'>0%</div>
    <div class="loading-text">
      ToletX Admin...
    </div>
  </div>
</div>
<?php /**PATH D:\new_project\toletx_search\resources\views/Dashboard/preloader/preloader.blade.php ENDPATH**/ ?>