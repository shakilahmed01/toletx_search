<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <div class="card-header">Search</div>
                <div class="card-body">
		            <form action="<?php echo e(route('search')); ?>" method="GET">
					    <?php echo csrf_field(); ?>
					    <input type="text" name="query" class="form-control" />
					    <input type="submit" class="btn btn-sm btn-primary" value="Search" style="margin-top: 10px;" />
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_project\toletx_search\resources\views/welcome.blade.php ENDPATH**/ ?>