<?php

namespace App\Http\Controllers;
use App\Models\Hostel;
use App\Models\Hotel;
use App\Models\Bilboard;
use App\Models\Community_Center;
use Illuminate\Http\Request;
use Spatie\Searchable\Search;

class TestController extends Controller
{
    public function index()
    {
      return view('welcome');
    }

    public function search(Request $request)
    {
       $searchResults = (new Search())
            ->registerModel(Hostel::class, 'hostel_name')
            ->registerModel(Hotel::class, 'hotel_name')
            ->registerModel(Bilboard::class, 'address')
            ->registerModel(Community_Center::class, 'community_name')
            ->perform($request->input('query'));

        return view('search', compact('searchResults'));
    }

}
